import Foundation
"""
"Instructions
Given a word, compute the Scrabble score for that word.

Letter Values
You'll need these:

Letter                           Value
A, E, I, O, U, L, N, R, S, T       1
D, G                               2
B, C, M, P                         3
F, H, V, W, Y                      4
K                                  5
J, X                               8
Q, Z                               10
Examples
"cabbage" should be scored as worth 14 points:

3 points for C
1 point for A, twice
3 points for B, twice
2 points for G
1 point for E
And to total:

3 + 2*1 + 2*3 + 2 + 1
= 3 + 2 + 6 + 3
= 5 + 9
= 14
Extensions
You can play a double or a triple letter.
You can play a double or a triple word.
"""
//1
class Scrabble1 {

    var letters: String
    var sum = 0

    func score() -> Int {
        letters = letters.uppercased()

        for letter in letters {
            switch letter {
            case "A", "E", "I", "O", "U", "L", "N", "R", "S", "T":
                sum += 1
            case "D", "G":
                sum += 2
            case "B", "C", "M", "P":
                sum += 3
            case "F", "H", "V", "W", "Y":
                sum += 4
            case "K":
                sum += 5
            case "J", "X":
                sum += 8
            case "Q", "Z":
                sum += 10
            default:
                sum = 0
            }
        }
        return sum
    }


    init(_ letters: String) {
        self.letters = letters
    }
}

//2
class Scrabble2 {

    var score: Int

    init(_ letters: String?) {
        self.score = Scrabble2.score(letters ?? "")
    }


    static func score(_ letters: String) -> Int {

        var sum = 0
        for letter in letters.uppercased() {
            switch letter {
            case "A", "E", "I", "O", "U", "L", "N", "R", "S", "T":
                sum += 1
            case "D", "G":
                sum += 2
            case "B", "C", "M", "P":
                sum += 3
            case "F", "H", "V", "W", "Y":
                sum += 4
            case "K":
                sum += 5
            case "J", "X":
                sum += 8
            case "Q", "Z":
                sum += 10
            default:
                sum = 0
            }
        }
        return sum
    }
}

